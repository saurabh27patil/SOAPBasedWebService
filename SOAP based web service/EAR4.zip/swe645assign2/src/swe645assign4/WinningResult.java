package swe645assign4;

public class WinningResult {

	
	private double mean;
	private double sd;
	public double getMean() {
		
		return mean;
	}
	public void setMean(double mean) {
		
		this.mean=mean;
	}

	public double getSd()
	{
		return sd;
	}
	
	public void setSd(double sd) {
		
		this.sd=sd;
	}
}
