package swe645assign4;

public class QueryParameter {
	private String lname;
	private String fname;
	private String city;
	private String state;
	public String getLname() {
		return lname;
	}
	public void setLname(String lastname) {
		this.lname = lastname;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String firstname) {
		this.fname = firstname;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}

}
